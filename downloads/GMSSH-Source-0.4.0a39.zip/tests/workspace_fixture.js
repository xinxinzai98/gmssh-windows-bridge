const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {Workspace}=require('../gmssh_windows_bridge/workspace.cjs');
const root=path.resolve(__dirname,'..'),folder=fs.mkdtempSync(path.join(os.tmpdir(),'gmssh-workspace-browser-')),workspace=new Workspace({root:folder});
// A separate loopback origin exercises the real parent/viewer message boundary.
const viewer=http.createServer((req,res)=>{
  const url=new URL(req.url,'http://127.0.0.1');
  if(url.pathname==='/config.json'){res.setHeader('content-type','application/json');res.end(JSON.stringify({target:'192.0.2.42',transport:'monitor',keychain:true,has_saved_password:false,requires_token:false,capabilities:{files:true,power:true}}));return;}
  const assets=path.join(root,'gmssh_windows_bridge/desktop_web');
  const file=url.pathname==='/fixture-preview.js'?path.join(__dirname,'workspace-viewer-preview.js'):path.resolve(assets,'.'+(url.pathname==='/'?'/index.html':url.pathname));
  if((!file.startsWith(assets+path.sep)&&file!==path.join(__dirname,'workspace-viewer-preview.js'))||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end();return;}
  res.setHeader('content-type',file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.png')?'image/png':'image/svg+xml');
  if(url.pathname==='/')res.end(fs.readFileSync(file,'utf8')+'<script src="/fixture-preview.js"></script>');else res.end(fs.readFileSync(file));
});
const desktop='<!doctype html><meta charset="utf-8"><style>body{margin:0;background:linear-gradient(135deg,#113176,#142b5b);color:#fff;font:18px system-ui;padding:35px;height:100vh;box-sizing:border-box}p{font-size:14px;opacity:.7}</style><h1>设计工作站</h1><p>Windows 桌面 · 本地合成画面</p><p>此画面不连接真实设备</p><script>const instance="synthetic-desktop";parent.postMessage({type:"gmssh-workspace-desktop",instance,state:"connected"},location.origin);parent.postMessage({type:"fixture-ready"},location.origin);addEventListener("message",e=>{if(e.data?.type==="fixture-preferences")parent.postMessage({type:"gmssh-workspace-desktop",instance,preferences:{quality:"best",zoom:"fit",display:0}},location.origin);});</script>';
const server=http.createServer(async(req,res)=>{try{
  const url=new URL(req.url,'http://127.0.0.1');if(url.pathname==='/workspace'&&req.method==='POST'){let raw='';for await(const part of req){raw+=part;if(raw.length>1024**2)throw Error('too large');}const {action,data}=JSON.parse(raw),result=action==='session'?workspace.event('synthetic-window',data):workspace.invoke(action,data);res.setHeader('content-type','application/json');res.end(JSON.stringify({status:'ok',data:result}));return;}
  if(url.pathname==='/workspace-state'){res.setHeader('content-type','application/json');res.end(JSON.stringify(workspace.view()));return;}
  if(url.pathname==='/pairing'){res.setHeader('content-type','text/html; charset=utf-8');res.end(fs.readFileSync(path.join(__dirname,'pairing-entry.html'),'utf8').replace('../desktop-web/public/gmssh-pairing.js?v=alpha12-unified-add','/gmssh-pairing.js'));return;}
  if(url.pathname==='/desktop-fixture'){res.setHeader('content-type','text/html; charset=utf-8');res.end(desktop);return;}
  if(url.pathname==='/workspace-small'){res.setHeader('content-type','text/html; charset=utf-8');res.end('<!doctype html><meta charset="utf-8"><title>工作区 · 420px 窄窗口预览</title><style>body{margin:20px;background:#141414;color:#aaa;font:14px system-ui}iframe{display:block;width:420px;height:700px;border:1px solid #36363e;border-radius:10px;margin-top:14px}</style><p>420px 窄窗口 · 本地合成界面，不连接真实设备</p><iframe title="窄窗口工作区" src="/"></iframe>');return;}
  const file=url.pathname==='/'?path.join(__dirname,'workspace-entry.html'):path.join(root,'desktop-web/public',url.pathname);if(!file.startsWith(root)||!fs.existsSync(file)){res.writeHead(404);res.end();return;}res.setHeader('content-type',file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':'image/svg+xml');
  if(url.pathname==='/'&&url.searchParams.has('viewer'))res.end(fs.readFileSync(file,'utf8').replace("frame.src='/desktop-fixture'","frame.src='http://127.0.0.1:"+viewer.address().port+"/'"));else res.end(fs.readFileSync(file));
}catch(error){res.statusCode=400;res.end(JSON.stringify({status:'error',code:error.code||'FIXTURE_ERROR'}));}});
viewer.listen(0,'127.0.0.1',()=>server.listen(0,'127.0.0.1',()=>console.log(JSON.stringify({url:'http://127.0.0.1:'+server.address().port+'/',viewerUrl:'http://127.0.0.1:'+viewer.address().port+'/'}))));process.on('SIGTERM',()=>server.close(()=>viewer.close(()=>{fs.rmSync(folder,{recursive:true,force:true});process.exit(0);})));
