import hashlib
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest import mock
from types import SimpleNamespace
import plistlib
import shutil
import subprocess
import sys

from gmssh_windows_bridge import __version__
from gmssh_windows_bridge.macos_launcher import _build_launcher, monitor_options, native_profile, refresh_executable_uuid, write_asar


class LauncherArchiveTest(unittest.TestCase):
    def test_bundles_vendor_resources_and_protocol_without_external_app_dependency(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            vendor = root / 'Official.app/Contents'
            (vendor / 'MacOS').mkdir(parents=True)
            (vendor / 'Frameworks').mkdir()
            (vendor / 'Resources/app.asar.unpacked').mkdir(parents=True)
            (vendor / 'Resources/app.asar').write_bytes(b'synthetic unmodified vendor archive')
            (vendor / 'Resources/app.asar.unpacked/native.node').write_bytes(b'synthetic native dependency')
            (vendor / 'MacOS/GMSSH').write_bytes(struct.pack('<8I', 0xFEEDFACF, 0x0100000C, 0, 2, 1, 24, 0, 0)
                                               + struct.pack('<II', 0x1B, 24) + b's' * 16)
            urls = [{'CFBundleURLSchemes': ['gmssh']}]
            (vendor / 'Info.plist').write_bytes(plistlib.dumps({
                'CFBundleIdentifier': 'com.gmssh.com', 'CFBundleShortVersionString': '2.0.4',
                'CFBundleURLTypes': urls, 'ElectronAsarIntegrity': {
                    'Resources/app.asar': {'algorithm': 'SHA256', 'hash': 'synthetic-vendor-header'}}}))
            profile = root / 'profile'
            for relative in ('serve/app/gs/bin/gs_main_mac_arm64', 'serve/multi/gmb_multi_server_mac_arm64'):
                file = profile / relative
                file.parent.mkdir(parents=True, exist_ok=True)
                file.write_bytes(b'synthetic-server')
            config = SimpleNamespace(gmssh_app=vendor.parent, profile=profile, python=Path(sys.executable),
                                     port=22243, target=None, label='Synthetic', machine_id=None,
                                     monitor_port=None, monitor_username=None, monitor_known_hosts=None,
                                     monitor_host_key=None, keychain=True, pairing_only=True)
            def run(args, **kwargs):
                if args[0] == 'cp':
                    source, destination = map(Path, args[-2:])
                    shutil.copytree(source, destination) if source.is_dir() else shutil.copyfile(source, destination)
                return subprocess.CompletedProcess(args, 0, b'', b'')
            output = root / 'Enhanced.app'
            with mock.patch('gmssh_windows_bridge.macos_launcher.subprocess.run', side_effect=run), \
                    mock.patch('gmssh_windows_bridge.macos_launcher.ctypes.CDLL'):
                _build_launcher(config, output)
            resources = output / 'Contents/Resources'
            self.assertEqual((resources / 'vendor.asar').read_bytes(), (vendor / 'Resources/app.asar').read_bytes())
            self.assertTrue((resources / 'vendor.asar.unpacked/native.node').is_file())
            self.assertFalse((resources / 'app.asar.unpacked').exists())
            raw = (resources / 'app.asar').read_bytes()
            _, length, _, text_size = struct.unpack('<4I', raw[:16])
            entry = json.loads(raw[16:16 + text_size])['files']['launcher-config.json']
            start = 8 + length + int(entry['offset'])
            payload = json.loads(raw[start:start + entry['size']])
            self.assertEqual(payload['vendorAsar'], 'vendor.asar')
            self.assertEqual(payload['profile'], str(profile))
            info = plistlib.loads((output / 'Contents/Info.plist').read_bytes())
            self.assertEqual(info['CFBundleURLTypes'], urls)
            self.assertEqual(info['ElectronAsarIntegrity']['Resources/vendor.asar']['hash'], 'synthetic-vendor-header')
            self.assertEqual(info['GMSSHBridgeVersion'], __version__)
            vendor.parent.rename(root / 'Official-offline.app')
            self.assertTrue((resources / payload['vendorAsar']).is_file())

    def test_profile_requires_initialized_servers_for_the_vendor_architecture(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / 'Contents'
            (source / 'MacOS').mkdir(parents=True)
            (source / 'MacOS/GMSSH').write_bytes(struct.pack('<II', 0xFEEDFACF, 0x0100000C))
            profile = root / 'profile'
            cfg = SimpleNamespace(profile=profile)
            with self.assertRaisesRegex(ValueError, '官方 GMSSH'):
                native_profile(cfg, source)
            for relative in ('serve/app/gs/bin/gs_main_mac_arm64', 'serve/multi/gmb_multi_server_mac_arm64'):
                server = profile / relative
                server.parent.mkdir(parents=True, exist_ok=True)
                server.write_bytes(b'synthetic-server')
            self.assertEqual(native_profile(cfg, source), profile)
            (source / 'MacOS/GMSSH').write_bytes(struct.pack('<II', 0xFEEDFACF, 0x01000007))
            with self.assertRaisesRegex(ValueError, 'serve'):
                native_profile(cfg, source)

    def test_copied_executable_has_an_independent_uuid_without_other_byte_changes(self):
        header = struct.pack('<8I', 0xFEEDFACF, 0, 0, 2, 1, 24, 0, 0)
        original = header + struct.pack('<II', 0x1B, 24) + b's' * 16 + b'unchanged code'
        with tempfile.TemporaryDirectory() as directory:
            executable = Path(directory) / 'GMSSH'
            executable.write_bytes(original)
            refresh_executable_uuid(executable)
            updated = executable.read_bytes()
            self.assertNotEqual(updated[40:56], original[40:56])
            self.assertEqual(updated[:40] + updated[56:], original[:40] + original[56:])
            executable.write_bytes(original[:32])
            with self.assertRaises(ValueError): refresh_executable_uuid(executable)
            self.assertEqual(executable.read_bytes(), original[:32])

    def test_archive_offsets_and_integrity_match_native_pickle_format(self):
        files = {'package.json': b'{"main":"launcher.cjs"}', 'launcher.cjs': b'// synthetic launcher\n'}
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / 'app.asar'
            digest = write_asar(destination, files)
            raw = destination.read_bytes()
            marker, header_size, payload_size, text_size = struct.unpack('<4I', raw[:16])
            self.assertEqual(marker, 4)
            self.assertEqual(header_size, payload_size + 4)
            header = raw[16:16 + text_size]
            self.assertEqual(hashlib.sha256(header).hexdigest(), digest)
            entries = json.loads(header)['files']
            for name, body in files.items():
                item = entries[name]
                start = 8 + header_size + int(item['offset'])
                self.assertEqual(raw[start:start + item['size']], body)
                self.assertEqual(item['integrity']['hash'], hashlib.sha256(body).hexdigest())

    def test_monitoring_is_opt_in_and_requires_distinct_verified_paths(self):
        cfg = SimpleNamespace(port=22243, monitor_port=None, monitor_target_port=22,
                              monitor_username=None, monitor_known_hosts=None, monitor_host_key=None)
        self.assertIsNone(monitor_options(cfg))
        cfg.monitor_username = 'synthetic-user'
        with self.assertRaises(ValueError): monitor_options(cfg)
        with tempfile.TemporaryDirectory() as directory:
            cfg.monitor_known_hosts = Path(directory) / 'known_hosts'
            cfg.monitor_host_key = Path(directory) / 'bridge_host_key'
            cfg.monitor_port = 22244
            with self.assertRaises(ValueError): monitor_options(cfg)
            cfg.monitor_known_hosts.write_text('# synthetic test fixture\n')
            result = monitor_options(cfg)
            self.assertEqual(result['username'], 'synthetic-user')
            self.assertTrue(Path(result['knownHosts']).samefile(cfg.monitor_known_hosts))
            self.assertEqual(result['hostKey'], str(cfg.monitor_host_key))
            self.assertNotIn('password', result)
            self.assertFalse(cfg.monitor_host_key.exists())
            for port in (0, 22243, 65536):
                cfg.monitor_port = port
                with self.assertRaises(ValueError): monitor_options(cfg)
