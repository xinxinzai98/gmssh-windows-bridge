import type { TransferTask, UploadEntry,PlacesCall } from './transfers';
import { Operations } from './operations';

type Call = (action:string,data?:Record<string,unknown>)=>Promise<any>;
const messages:Record<string,string>={
  HOST_UNVERIFIED:'尚未确认 SSH 主机指纹，文件连接已停止',HOST_PINS_INVALID:'本机 SSH 主机身份记录不可读，原记录已保留',HOST_PINS_WRITE_FAILED:'主机身份未能保存，请检查本机空间和权限',AUTH_FAILED:'连接认证失败，请核对设备凭据或独立授权状态',INVALID_PRIVATE_KEY:'SSH 私钥或私钥口令无效，请检查连接配置',
  PLACES_INVALID:'常用目录记录无法读取，原记录已保留，其他文件功能仍可使用',PLACES_WRITE_FAILED:'常用目录未能保存，请检查本机空间或权限',PLACES_LIMIT:'每台设备最多收藏 12 个目录，请先移除不常用的收藏',INVALID_PLACE:'收藏目录信息无效，请重新选择',PLACE_NOT_FOUND:'该收藏已被移除，请重新打开常用目录列表',
  COMMIT_UNSUPPORTED:'该磁盘不支持不覆盖保存，临时文件已保留；请选择其他磁盘重新下载',
  CANCELLED_FILE_RETAINED:'已取消；达到完整大小的目标文件已保留，可继续核验',
  PARTIAL_MISSING:'所选目录未找到已传部分，请选择原目录或重新挂载后的同一目录',
  VOLUME_UNAVAILABLE:'磁盘或网络盘暂不可用，请重新连接并确认原保存位置后继续',READ_ONLY_VOLUME:'目标磁盘为只读，请检查挂载方式或选择其他磁盘',FILE_TOO_LARGE:'文件超过目标文件系统的限制，请选择支持大文件的磁盘',
  INVALID_NAME:'文件名不适合目标系统，请更名后重新选择',INVALID_PATH:'请先打开目标磁盘或普通文件夹',INVALID_GRANT:'请在系统窗口重新选择本机文件或保存位置',
  PAUSED:'已暂停，保留已传部分',REAUTHORIZE:'重新选择源文件或确认保存位置后继续',
  NEED_CONNECTION:'请先连接此设备的监控，再继续传输',PEER_CHANGED:'设备身份已变化，请核对连接配置',
  SOURCE_CHANGED:'源文件已变化，请重新创建传输任务',PARTIAL_CHANGED:'已传部分的标识或内容已变化，原文件已保留；请确认原磁盘位置后继续核对',
  HASH_MISMATCH:'内容校验未通过，文件尚未提交',CONFLICT:'目标已有同名文件；下载可点继续另存，上传可改名后继续',
  ACCESS_DENIED:'没有读写权限，请检查所选文件或目录',DISK_FULL:'空间不足，释放空间后可继续',
  DEVICE_CONFIG_CHANGED:'设备连接配置已变化，请先核对该设备',DEVICE_CONFIG_UNAVAILABLE:'设备配置未就绪，请重新连接',
  JOURNAL_INVALID:'任务记录无法读取，原记录已保留，请检查本机文件中心',JOURNAL_WRITE_FAILED:'任务记录无法保存，传输已停止',
  TARGET_CHANGED:'请选择原保存位置，避免恢复到其他文件',UNSUPPORTED_FILE:'仅支持普通文件和文件夹，暂不跟随链接',
  PICKER_BUSY:'已有文件选择窗口，请先完成该窗口',QUERY_BUSY:'正在核对连接，请稍后再试',
  TRANSFER_LIMIT:'最多 2000 项、单文件 1 TiB；请分批传输',CANCELLED:'已取消',TRANSFER_IO:'传输中断，已传部分已保留，可继续',
  REMOTE_IO:'远端读写失败，检查连接或权限后可继续',PROTOCOL_UNSUPPORTED:'本地文件服务版本不匹配，请重开更新后的管理端',
  OPERATION_TIMEOUT:'等待远端响应超时，请核对原任务后继续',OPERATION_INTERRUPTED:'操作响应中断，请核对原任务后继续',
  SESSION_CLOSED:'文件会话已结束或权限已变更，请重新核对授权',SERVER_UPGRADE_REQUIRED:'此授权需要更新管理端或服务端',
  LOCAL_SERVICE_UNAVAILABLE:'本机文件服务尚未启动，已传部分保留；待服务就绪后继续',LOCAL_SERVICE_TIMEOUT:'本机文件服务启动或握手超时，请重开文件中心后继续',LOCAL_SERVICE_BUSY:'本机文件通道暂忙，请等待其他操作结束后继续',LOCAL_AUTH_FAILED:'本机操作授权已刷新，请重开管理端后继续',
  CONNECTION_CLOSED:'文件连接已关闭，已传部分保留；核对连接后继续',WORKER_START_FAILED:'文件工作进程未能启动，请检查管理端安装和权限',WORKER_EXITED:'文件工作进程提前退出，任务已保留；可复制诊断后继续',WORKER_NO_RESULT:'文件工作进程没有返回结果，请核对任务后继续',DIAGNOSTIC_COPY_FAILED:'诊断未能复制，请重试',
};
export const transferMessage=(code:string)=>messages[code]||'文件任务暂不可用，请检查连接后继续';
export const transferStageMessage=(stage?:string)=>({
  'device-config':'正在核对设备配置','worker-start':'正在启动文件工作进程','local-connect':'正在等待本机文件服务','local-auth':'正在核对本机操作授权','peer-ready':'正在等待设备连接就绪','local-file':'正在核对本机文件权限','file-prepare':'正在打开并核对远端文件',
  'transferring':'文件传输','verifying':'内容校验','saving':'最终保存',
} as Record<string,string>)[stage||'']||'';
export class NativeFileOperations extends Operations {
  constructor(private call:Call){super(()=>'');}
  override async request(op:string,values:Record<string,unknown>={}){if(op!=='list'&&op!=='mkdir')throw Error('文件操作不受支持');return this.call('fs-'+op,values);}
  override close(){} // Each bounded main-process request releases its own SFTP channel.
}
export function nativeCall(send:(type:string,data:Record<string,unknown>)=>void){
  let next=0;const pending=new Map<number,{resolve:(value:any)=>void;reject:(error:Error)=>void;timer:number}>();
  const receive=(event:MessageEvent)=>{
    if(event.source!==window.parent||event.data?.type!=='gmssh-file-native-result')return;
    const value=pending.get(event.data.requestId);if(!value)return;pending.delete(event.data.requestId);clearTimeout(value.timer);
    const reply=event.data.reply;if(reply?.status==='ok')value.resolve(reply.data);else value.reject(Object.assign(Error(transferMessage(reply?.code)),{code:reply?.code||'UNSUPPORTED'}));
  };
  window.addEventListener('message',receive);
  const call:Call=(action,data={})=>new Promise((resolve,reject)=>{const requestId=++next,timer=window.setTimeout(()=>{pending.delete(requestId);reject(Object.assign(Error('文件中心未响应，请重开管理端'),{code:'UNSUPPORTED'}));},action==='hello'?3000:600_000);pending.set(requestId,{resolve,reject,timer});send('gmssh-file-native',{requestId,action,data});});
  window.addEventListener('pagehide',()=>{window.removeEventListener('message',receive);for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('文件页已关闭'));}pending.clear();},{once:true});
  return call;
}
export class NativeTransfers {
  readonly native=true;items:TransferTask[]=[];private timer?:number;private disposed=false;private polling=false;
  places?:PlacesCall;
  constructor(private call:Call,private changed:(tasks:readonly TransferTask[])=>void,places=false){if(places)this.places=async(op,values)=>{try{return await this.call('places',{op,...values});}catch(error){if(['TRANSFER_IO','REMOTE_IO'].includes((error as {code?:string}).code||''))throw Object.assign(Error('无法核对设备连接，请检查连接后重试。'),{code:(error as {code:string}).code});throw error;}};void this.refresh();this.timer=window.setInterval(()=>void this.refresh(),700);}
  async refresh(){if(this.disposed||this.polling)return;this.polling=true;try{const value=await this.call('list');if(this.disposed)return;if(!Array.isArray(value.jobs))throw Error('任务返回格式无效');this.items=value.jobs.map((j:any)=>({id:j.id,kind:j.kind,name:j.name,path:'',relative:j.name,status:j.status,bytes:j.bytes,size:j.size,started:j.started||Date.now(),createdAt:j.createdAt,source:j.source,target:j.target,code:j.code,sha256:j.sha256,cleanupPending:!!j.cleanupPending,copyBytes:j.copyBytes||0,phase:j.phase,stage:j.stage,diagnostic:j.diagnostic,verifyBytes:j.verifyBytes||0,verifyTotal:j.verifyTotal||0,message:j.status==='done'?'已校验并保存':transferMessage(j.code||'PAUSED')+(j.needsGrant&&['paused','failed','cancelled'].includes(j.status)?' · 需确认本机文件权限':'' )}));this.changed(this.items);}catch(error){if(!this.disposed){const note=document.getElementById('file-feedback');if(note){note.hidden=false;note.textContent=error instanceof Error?error.message:'任务列表暂不可用';}}}finally{this.polling=false;}}
  async action(action:string,data:Record<string,unknown>={}){await this.call(action,data);await this.refresh();}
  chooseUploads(remote:string,directory:boolean){return this.action('pick-upload',{remote,directory});}
  addUploads(entries:UploadEntry[],remote:string){return this.action('pick-upload',{remote,directory:entries.some(e=>!!e.directory),hints:entries.map(e=>({relative:e.relative,name:e.file?.name||e.relative.split('/').at(-1),directory:!!e.directory,size:e.file?.size||0,modified:e.file?.lastModified||0}))});}
  addDownloads(entries:{path:string;name:string;directory:boolean;size:number}[]){return this.action('pick-download',{entries});}
  retry(id:number,name?:string){return this.action('resume',name?{id,name}:{id});}
  pause(id:number){return this.action('pause',{id});}
  copyDiagnostic(id:number){return this.action('copy-diagnostic',{id});}
  cancel(id:number){return this.action('cancel',{id});}
  cancelAll(){return this.action('cancel-all');}
  clearFinished(){return this.action('clear');}
  dispose(){this.disposed=true;clearInterval(this.timer);}
}
